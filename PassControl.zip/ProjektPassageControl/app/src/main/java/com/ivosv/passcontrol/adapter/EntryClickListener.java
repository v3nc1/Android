package com.ivosv.passcontrol.adapter;

import com.ivosv.passcontrol.model.PassEntry;

public interface EntryClickListener {

    public void onItemClick(PassEntry record);
}
